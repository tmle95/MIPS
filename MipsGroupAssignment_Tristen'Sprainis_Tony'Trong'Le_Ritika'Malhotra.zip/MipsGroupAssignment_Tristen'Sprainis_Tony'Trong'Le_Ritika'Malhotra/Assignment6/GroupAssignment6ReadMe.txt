Assignment 6
Write a MIPS program that implements insertion sort over an array of integers.
Insertion Sort is another method of sorting an array. It involves taking each element of an array and finding its place in a sorted segment of the array, which is placed at the beginning and grown throughout the algorithm.
The algorithm is given on the next slide:
For(int i = 1; i < size; i++) {
	int j = i;
	while(j > 0 && array[j] > array[j-1]) {
		int temp = array[j-1];
		array[j-1] = array[j];
		array[j] = temp;
		j--;
	}
}

Problems Encountered:
Before optimizing code, I had initially made two print functions. One printed, the other sorted and printed. This caused the code to be longer than it needed to be. I also was unsure how to use pointers in Mips when I started this assignment.

Things I learned:
I learned how to use pointers and implement functions to work for only its intended purpose.
