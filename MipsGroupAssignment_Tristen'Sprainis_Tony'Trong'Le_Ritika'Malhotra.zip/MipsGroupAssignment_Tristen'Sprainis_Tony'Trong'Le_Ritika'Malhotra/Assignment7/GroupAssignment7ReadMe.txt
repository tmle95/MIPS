Assignment 7
Write a program in MIPS that performs a recursive binary search on an array of integers. You may assume that the array is sorted.

Problems Encountered:
For the assignment #7, with the implemention of binary search on a list of numbers, there were a couple problems that were encountered. One being determining actually how much space for stacks was required. Another problem was locating the middle index of the list and then implement how to traverse the list as the middle index. After resolving the issue with the middle index, another issue came up right after involving the comparing it to the left and right. Searching the left of the mid index initially did not result in the correct outputs and therefore required a branch. This was solved by proceeding into searching the right half as a priority.

Things Learned:
I learned how to locate and traverse a middle index of a list and then search respectively to find a result.