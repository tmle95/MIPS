Assignment 3
Write a MIPS program that finds the maximum, minimum, and mean (rounded down to an integer value) of an array of integers and prints them to the screen.

Problems Encountered:
There was a problem with figuring out how to recieve both the minimum and maximum within a single loop.

Things Learned:
Do not try to implement two different branch to get two different results in a single loop, create another function and use jal.