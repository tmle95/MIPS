Assignment 10
Write a program in MIPS that:
Prompts the user for the name of a text file. If the file open operation fails, notify the user and close the program.
Continually prompts the user for text input. Writes all user input to the text file whose name was given as input.
Once the user has entered a pre-determined number of strings (no less than 10), close the text file and close the program.

Problems Encountered:
Reading a valid text file.
Storing string inputs into memory.
Writing to the text file and having the output file receieve the correct data that was inputted.

Things Learned:
How to write to an output file.
Prompt user to input strings.
Handle errors as an exception.