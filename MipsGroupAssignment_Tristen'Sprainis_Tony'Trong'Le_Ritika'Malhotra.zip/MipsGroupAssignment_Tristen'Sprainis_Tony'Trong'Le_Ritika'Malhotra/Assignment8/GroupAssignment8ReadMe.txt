Assignment 8
Write a program that takes as input an integer n between 0 and 30 and prints the nth Fibonacci and Lucas number.
You MUST use the following definitions of Lucas and Fibonacci numbers in your program:
L(0) = 2; L(1) = 1; L(2) = 3
L(m+n) = L(m+1) * F(n) + L(m) * F(n-1) for (m+n) > 2, where m <= n
F(0) = 0; F(1) = 1; F(2) = 1
F(n) = (L(n + 1) + L(n-1)) / 5 for n > 2

The main problems I encountered with this program was keeping track between the two different arrays, knowing when to use the lucas numbers to caluclate the fibonacci number, and when to use the fibonacci numbers to calculate the lucas numbers. This caused some major headaches for keeping everything between them straight. 

Things I learned from this assignment:
How not to rage at the computer when you can't keep track of the arrays. Also, how to manipulate an array pointer to point to the next and previous numbers in the array by adding and subtracting 4 bytes.