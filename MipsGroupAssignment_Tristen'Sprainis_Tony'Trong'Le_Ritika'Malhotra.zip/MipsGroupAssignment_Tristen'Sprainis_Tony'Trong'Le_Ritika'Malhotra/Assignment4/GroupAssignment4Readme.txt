Assignment 4
Write a program that takes two integers A and B as input, calculates A choose B, and prints the result to the screen.
A choose B = A! / (B! * (A-B)!)

Problems encountered:
The problem I encountered the most was trying to figure out a way to calculate when A was less than B.

Things I learned:
Mips only will calculate up to factorial 12, meaning after 12, the output will not be what is expected of the program to output.
