Assignment 1
Write a program that prompts the user for an integer between 0 and 13. The program should then calculate the factorial value of each integer from 0 to the value entered. Each of these factorial values should also be stored in an array.

Problems Encountered:
No major problems were encountered.

Things Learned:
I learned that mips can only calculate up to 12 factorial.
