Assignment 2
Write a MIPS program that takes as input an integer from the user, finds all of that number�s prime factors, and prints those prime factors to the screen.

Problems Encountered:
The biggest problem I ran into was figuring out how to find the factorization of numbers that had more than one of the same facorization numbers that was greater than 2.

Things Learned:
I learned how to manipulate conditions of loops to allow me to break out to print the last number in the list.