Assignment 5
Write a MIPS program that implements selection sort over an array of integers.
Selection sort is an algorithm for sorting an array.  It involves iterating through an array of size n n times, finding the nth-smallest element, and placing it in the nth position in the array.
The algorithm is given on the following slide:
for(int i = 0; i < (size � 1); i++) {
	int jMin = i;
	for(int j = i+1; j < size; j++) {
		if(array[j] < array[jMin])
			jMin = j;
	}
	if(jMin != i) {
		int temp = a[j];
		array[j] = array[iMin];
		array[iMin] = temp;
	}
}

Problems Encountered:
For assignment #5, while implementing selection sort on a list of numbers, one problem that initially came up was determining the amount of space required for the stack pointer. Another small problem while doing this assignment was correctly implementing a loop that would traverse the list and locate the local minimum of the list. The primary problem from this assignment was comparing the the elements of the list, as multiple declaration of different variables in reference to the index was required, and then comparing them to the relating elements of the index.  

Things Learned:
I learned how to utilize multiple variables in relation to the index of an array, and compare them.