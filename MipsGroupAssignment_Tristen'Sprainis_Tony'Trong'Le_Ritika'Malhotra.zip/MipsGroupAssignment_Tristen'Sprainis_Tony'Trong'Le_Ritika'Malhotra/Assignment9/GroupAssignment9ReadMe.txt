Assignment 9
Write a program in MIPS that:
	Prompts the user for the name of a text file. If the file open operation fails, notify the user and close the program.
	Reads all text from the file whose name was given as input and prints it to the screen.
	Once there is no longer any input, closes the file and closes the program.

Problems Encountered:
When prompting the user to input a text file name, the string input would not be a balid file descriptor for the "read from file" syscall function because it contained extra characters. Therefore, a clean function was required to validate the text input before allowing the syscall function to read it.

Things Learned:
Prompt user to input "strings" and then storing it into memory.(Completely different from integers).
How to write a clean function to validate text input.